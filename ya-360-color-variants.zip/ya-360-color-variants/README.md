# YA-360 renk varyasyonları

Her iki özgün SVG için 15 renk varyasyonu. Tüm dosyalar özgün 32×32 viewBox ve geometrisini korur.

- b2c: üç duraklı gradyan renkleri değiştirildi.
- b2b: dolgu ve kenarlık renkleri değiştirildi.
- Beyaz sembol, ölçüler ve tasarım geometrisi korunmuştur.
